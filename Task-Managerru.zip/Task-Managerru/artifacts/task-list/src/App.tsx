import { type FormEvent, type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  useCreateTask,
  useDeleteTask,
  useGetTaskSummary,
  useHealthCheck,
  useListTasks,
  useUpdateTask,
  getGetTaskSummaryQueryKey,
  getListTasksQueryKey,
  setBaseUrl,
} from '@workspace/api-client-react';
import type { Task } from '@workspace/api-client-react';
import {
  AlertCircle,
  CalendarDays,
  Check,
  CheckCheck,
  CircleHelp,
  ClipboardList,
  Clock3,
  FileText,
  ListTodo,
  LoaderCircle,
  Plus,
  Search,
  Sparkles,
  Trash2,
  X,
  Pencil,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

setBaseUrl(import.meta.env.BASE_URL.replace(/\/$/, ''));

const queryClient = new QueryClient();
type StatusFilter = 'all' | 'active' | 'completed';
type Priority = 'low' | 'medium' | 'high';
type Draft = { title: string; notes: string; priority: Priority; dueDate: string };
const blankDraft: Draft = { title: '', notes: '', priority: 'medium', dueDate: '' };

function dateLabel(date: string) {
  const parsed = new Date(`${date.slice(0, 10)}T12:00:00`);
  if (Number.isNaN(parsed.getTime())) return date;
  return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short' }).format(parsed);
}

function isOverdue(task: Task) {
  return !task.completed && !!task.dueDate && task.dueDate.slice(0, 10) < new Date().toISOString().slice(0, 10);
}

function AppHome() {
  const client = useQueryClient();
  const [filter, setFilter] = useState<StatusFilter>('all');
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Task | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [draft, setDraft] = useState<Draft>(blankDraft);
  const [formError, setFormError] = useState('');
  const listParams = { status: filter, q: search.trim() || undefined };
  const tasksQuery = useListTasks(listParams);
  const summaryQuery = useGetTaskSummary();
  const healthQuery = useHealthCheck();
  const createTask = useCreateTask();
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();
  const summary = summaryQuery.data;
  const tasks = tasksQuery.data ?? [];

  const invalidateTasks = () => {
    client.invalidateQueries({ queryKey: getListTasksQueryKey() });
    client.invalidateQueries({ queryKey: getGetTaskSummaryQueryKey() });
  };

  const startCreate = () => {
    setDraft(blankDraft);
    setEditing(null);
    setFormError('');
    setIsCreating(true);
  };

  const startEdit = (task: Task) => {
    setDraft({
      title: task.title,
      notes: task.notes ?? '',
      priority: task.priority,
      dueDate: task.dueDate?.slice(0, 10) ?? '',
    });
    setEditing(task);
    setFormError('');
    setIsCreating(true);
  };

  const closeModal = () => {
    setIsCreating(false);
    setEditing(null);
    setFormError('');
  };

  const submitTask = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const title = draft.title.trim();
    if (!title) {
      setFormError('Добавьте название задачи.');
      return;
    }
    if (title.length > 200) {
      setFormError('Название не должно быть длиннее 200 символов.');
      return;
    }
    setFormError('');
    const data = {
      title,
      notes: draft.notes.trim() || null,
      priority: draft.priority,
      dueDate: draft.dueDate || null,
    };
    if (editing) {
      updateTask.mutate({ id: editing.id, data }, {
        onSuccess: () => {
          invalidateTasks();
          closeModal();
        },
        onError: () => setFormError('Не удалось сохранить изменения. Попробуйте ещё раз.'),
      });
    } else {
      createTask.mutate({ data }, {
        onSuccess: () => {
          invalidateTasks();
          closeModal();
        },
        onError: () => setFormError('Не удалось добавить задачу. Попробуйте ещё раз.'),
      });
    }
  };

  const toggleTask = (task: Task) => {
    updateTask.mutate({ id: task.id, data: { completed: !task.completed } }, {
      onSuccess: invalidateTasks,
    });
  };

  const removeTask = (task: Task) => {
    if (!window.confirm(`Удалить задачу «${task.title}»?`)) return;
    deleteTask.mutate({ id: task.id }, { onSuccess: invalidateTasks });
  };

  const loading = tasksQuery.isLoading;
  const error = tasksQuery.isError;
  const completedRatio = summary && summary.total > 0 ? Math.round((summary.completed / summary.total) * 100) : 0;

  return (
    <main className="app-shell">
      <div className="app-frame">
        <header className="topline">
          <div className="brand">
            <div className="brand-mark"><ListTodo size={19} strokeWidth={2.1} /></div>
            <span>список задач</span>
            <span className="brand-caption">личное пространство</span>
          </div>
          <div className="health" data-testid="status-api-health">
            <span className="health-dot" style={{ background: healthQuery.isError ? '#bd674f' : undefined }} />
            {healthQuery.isLoading ? 'Проверяем связь' : healthQuery.isError ? 'Связь с сервером потеряна' : 'Всё синхронизировано'}
          </div>
        </header>

        <section className="hero-row">
          <div>
            <p className="eyebrow">Ваш ритм, ваши планы</p>
            <h1 className="page-title">Дела по порядку.</h1>
            <p className="hero-subtitle">Соберите важное в одном месте — и освободите голову.</p>
          </div>
          <button className="add-button" onClick={startCreate} data-testid="button-add-task">
            <Plus size={17} /> Новая задача
          </button>
        </section>

        <section className="overview" aria-label="Сводка задач">
          <div className="overview-card primary-card" data-testid="stat-total">
            <div className="stat-label"><ClipboardList size={14} /> Всего задач</div>
            <div className="stat-value">{summaryQuery.isLoading ? '—' : summary?.total ?? '—'}</div>
            <div className="stat-foot">{summary?.total ? `Завершено ${completedRatio}%` : 'Начните с одной небольшой задачи'}</div>
          </div>
          <div className="overview-card" data-testid="stat-active">
            <div className="stat-label"><Clock3 size={14} /> В работе</div>
            <div className="stat-value">{summaryQuery.isLoading ? '—' : summary?.active ?? '—'}</div>
          </div>
          <div className="overview-card" data-testid="stat-completed">
            <div className="stat-label"><CheckCheck size={14} /> Готово</div>
            <div className="stat-value">{summaryQuery.isLoading ? '—' : summary?.completed ?? '—'}</div>
          </div>
          <div className="overview-card" data-testid="stat-overdue">
            <div className="stat-label"><CalendarDays size={14} /> Просрочено</div>
            <div className="stat-value">{summaryQuery.isLoading ? '—' : summary?.overdue ?? '—'}</div>
          </div>
        </section>

        <section className="tasks-panel" aria-label="Список задач">
          <div className="panel-head">
            <div>
              <h2 className="panel-title">Ваш список</h2>
              <p className="panel-count">{summary?.active ?? 0} {summary?.active === 1 ? 'задача ждёт' : 'задач ждут'} своего часа</p>
            </div>
            <div className="tools">
              <label className="search-wrap">
                <Search size={16} />
                <input
                  type="search"
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder="Найти задачу"
                  aria-label="Поиск задач"
                  data-testid="input-search-tasks"
                />
              </label>
              <div className="filter-tabs" role="tablist" aria-label="Фильтр задач">
                {([
                  ['all', 'Все'],
                  ['active', 'В работе'],
                  ['completed', 'Готово'],
                ] as const).map(([value, label]) => (
                  <button
                    key={value}
                    className={`filter-tab ${filter === value ? 'active' : ''}`}
                    onClick={() => setFilter(value)}
                    role="tab"
                    aria-selected={filter === value}
                    data-testid={`filter-${value}`}
                  >{label}</button>
                ))}
              </div>
            </div>
          </div>

          {loading ? (
            <div className="loading-state" aria-label="Загрузка списка">
              <div style={{ width: '100%' }}>
                {[0, 1, 2, 3].map((item) => <div className="skeleton-row" key={item}><span className="skeleton-dot" /><span className="skeleton-line" style={{ width: `${58 + item * 7}%` }} /></div>)}
              </div>
            </div>
          ) : error ? (
            <div className="error-state" role="alert" data-testid="status-tasks-error">
              <div>
                <div className="empty-icon"><AlertCircle size={22} /></div>
                <h3>Список пока не загрузился</h3>
                <p>Проверьте соединение и попробуйте обновить данные.</p>
                <button className="retry" onClick={() => { tasksQuery.refetch(); summaryQuery.refetch(); }}>Попробовать снова</button>
              </div>
            </div>
          ) : tasks.length === 0 ? (
            <div className="empty-state" data-testid="status-empty-tasks">
              <div>
                <div className="empty-icon">{search ? <Search size={21} /> : filter === 'completed' ? <Sparkles size={21} /> : <CircleHelp size={21} />}</div>
                <h3>{search ? 'Ничего не нашлось' : filter === 'completed' ? 'Пока нечего отметить' : filter === 'active' ? 'Все дела сделаны?' : 'Здесь появятся ваши дела'}</h3>
                <p>{search ? 'Попробуйте изменить запрос или очистить поиск.' : filter === 'completed' ? 'Когда задача будет выполнена, она появится здесь.' : filter === 'active' ? 'В списке нет незавершённых задач.' : 'Добавьте первую задачу — и мысли станут чуть свободнее.'}</p>
                {!search && filter === 'all' && <button className="retry" onClick={startCreate}>Добавить задачу</button>}
              </div>
            </div>
          ) : (
            <ul className="task-list">
              {tasks.map((task, index) => (
                <li className="task-row" key={task.id} style={{ animationDelay: `${Math.min(index * 45, 180)}ms` }} data-testid={`task-row-${task.id}`}>
                  <input
                    className="task-check"
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => toggleTask(task)}
                    aria-label={task.completed ? `Вернуть в работу: ${task.title}` : `Отметить выполненной: ${task.title}`}
                    data-testid={`checkbox-complete-${task.id}`}
                  />
                  <div className="task-main">
                    <div className="task-title-line">
                      <span className={`task-title ${task.completed ? 'done' : ''}`} data-testid={`text-task-title-${task.id}`}>{task.title}</span>
                    </div>
                    {task.notes && <p className="task-notes" data-testid={`text-task-notes-${task.id}`}><FileText size={12} style={{ verticalAlign: '-2px', marginRight: 5 }} />{task.notes}</p>}
                    <div className="task-meta">
                      <span className={`priority priority-${task.priority}`}>{task.priority === 'high' ? 'Высокий' : task.priority === 'medium' ? 'Средний' : 'Низкий'}</span>
                      {task.dueDate && <span className={`due ${isOverdue(task) ? 'overdue' : ''}`} data-testid={`text-task-due-${task.id}`}><CalendarDays size={12} />{isOverdue(task) ? 'Просрочено · ' : 'До '}{dateLabel(task.dueDate)}</span>}
                    </div>
                  </div>
                  <div className="row-actions">
                    <button className="icon-button" onClick={() => startEdit(task)} title="Редактировать" aria-label={`Редактировать: ${task.title}`} data-testid={`button-edit-${task.id}`}><Pencil size={15} /></button>
                    <button className="icon-button delete" onClick={() => removeTask(task)} title="Удалить" aria-label={`Удалить: ${task.title}`} data-testid={`button-delete-${task.id}`}><Trash2 size={15} /></button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
        <button className="mobile-add" onClick={startCreate} aria-label="Добавить задачу" data-testid="button-add-task-mobile"><Plus size={23} /></button>
      </div>

      {isCreating && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) closeModal(); }}>
          <form className="task-modal" onSubmit={submitTask} aria-label={editing ? 'Редактирование задачи' : 'Новая задача'}>
            <div className="modal-head">
              <div>
                <h2 className="modal-title">{editing ? 'Изменить задачу' : 'Новая задача'}</h2>
                <p className="modal-note">{editing ? 'Уточните детали и сохраните.' : 'Запишите главное, остальное можно добавить позже.'}</p>
              </div>
              <button className="icon-button" type="button" onClick={closeModal} aria-label="Закрыть" data-testid="button-close-task-form"><X size={18} /></button>
            </div>
            <div className="field">
              <label htmlFor="task-title">Название</label>
              <input id="task-title" value={draft.title} onChange={(event) => setDraft({ ...draft, title: event.target.value })} placeholder="Например, подготовить план на неделю" maxLength={200} autoFocus data-testid="input-task-title" />
            </div>
            <div className="field">
              <label htmlFor="task-notes">Заметка <span style={{ fontWeight: 400, color: '#98a198' }}>— необязательно</span></label>
              <textarea id="task-notes" value={draft.notes} onChange={(event) => setDraft({ ...draft, notes: event.target.value })} placeholder="Контекст, ссылка или следующая мысль" maxLength={2000} data-testid="input-task-notes" />
            </div>
            <div className="field-row">
              <div className="field">
                <label htmlFor="task-priority">Приоритет</label>
                <select id="task-priority" value={draft.priority} onChange={(event) => setDraft({ ...draft, priority: event.target.value as Priority })} data-testid="select-task-priority">
                  <option value="low">Низкий</option>
                  <option value="medium">Средний</option>
                  <option value="high">Высокий</option>
                </select>
              </div>
              <div className="field">
                <label htmlFor="task-date">Срок</label>
                <input id="task-date" type="date" value={draft.dueDate} onChange={(event) => setDraft({ ...draft, dueDate: event.target.value })} data-testid="input-task-due-date" />
              </div>
            </div>
            {formError && <p role="alert" style={{ color: '#a94e40', fontSize: 12, margin: '-3px 0 0' }} data-testid="status-form-error">{formError}</p>}
            <div className="modal-actions">
              <button className="secondary-button" type="button" onClick={closeModal} data-testid="button-cancel-task">Отмена</button>
              <button className="save-button" type="submit" disabled={createTask.isPending || updateTask.isPending} data-testid="button-save-task">
                {(createTask.isPending || updateTask.isPending) ? <LoaderCircle size={15} className="animate-spin" /> : <><Check size={15} /> {editing ? 'Сохранить' : 'Добавить'}</>}
              </button>
            </div>
          </form>
        </div>
      )}
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={AppHome} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
