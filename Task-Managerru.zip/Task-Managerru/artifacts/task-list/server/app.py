from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any

import psycopg
from flask import Flask, jsonify, request
from psycopg.rows import dict_row
from werkzeug.exceptions import HTTPException


API_PREFIX = "/task-list/api"
DATABASE_URL = os.environ.get("DATABASE_URL")
PRIORITIES = {"low", "medium", "high"}
TASK_COLUMNS = """
    id,
    title,
    notes,
    completed,
    priority,
    due_date,
    created_at,
    updated_at
"""

app = Flask(__name__)


class APIError(Exception):
    def __init__(self, message: str, status_code: int = 400) -> None:
        super().__init__(message)
        self.status_code = status_code


def connect() -> psycopg.Connection[Any]:
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is required to run the task API.")
    return psycopg.connect(DATABASE_URL, row_factory=dict_row)


def serialize_task(row: dict[str, Any]) -> dict[str, Any]:
    def iso(value: datetime | None) -> str | None:
        return value.isoformat() if value is not None else None

    return {
        "id": row["id"],
        "title": row["title"],
        "notes": row["notes"],
        "completed": row["completed"],
        "priority": row["priority"],
        "dueDate": iso(row["due_date"]),
        "createdAt": iso(row["created_at"]),
        "updatedAt": iso(row["updated_at"]),
    }


def parse_due_date(value: Any) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, str) or not value.strip():
        raise APIError("Срок должен быть датой или пустым значением.")

    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as error:
        raise APIError("Не удалось распознать срок задачи.") from error

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def require_object_body(allowed_fields: set[str]) -> dict[str, Any]:
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        raise APIError("Ожидался JSON-объект.")
    unknown = set(payload) - allowed_fields
    if unknown:
        raise APIError("В запросе есть неподдерживаемые поля.")
    return payload


def clean_title(value: Any) -> str:
    if not isinstance(value, str):
        raise APIError("Укажите название задачи.")
    title = value.strip()
    if not title:
        raise APIError("Название задачи не может быть пустым.")
    if len(title) > 200:
        raise APIError("Название должно быть не длиннее 200 символов.")
    return title


def clean_notes(value: Any) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise APIError("Заметка должна быть текстом.")
    if len(value) > 2000:
        raise APIError("Заметка должна быть не длиннее 2000 символов.")
    return value.strip() or None


def clean_priority(value: Any) -> str:
    if value not in PRIORITIES:
        raise APIError("Выберите допустимый приоритет.")
    return value


@app.errorhandler(APIError)
def handle_api_error(error: APIError):
    return jsonify({"error": str(error)}), error.status_code


@app.errorhandler(HTTPException)
def handle_http_error(error: HTTPException):
    return jsonify({"error": error.description}), error.code or 500


@app.errorhandler(Exception)
def handle_unexpected_error(error: Exception):
    app.logger.exception("Task API request failed", exc_info=error)
    return jsonify({"error": "Не удалось выполнить запрос. Попробуйте ещё раз."}), 500


@app.get(f"{API_PREFIX}/healthz")
def health_check():
    with connect() as connection:
        connection.execute("SELECT 1")
    return jsonify({"status": "healthy"})


@app.get(f"{API_PREFIX}/tasks")
def list_tasks():
    status = request.args.get("status", "all")
    if status not in {"all", "active", "completed"}:
        raise APIError("Неизвестный фильтр задач.")

    clauses: list[str] = []
    values: list[Any] = []
    if status == "active":
        clauses.append("completed = FALSE")
    elif status == "completed":
        clauses.append("completed = TRUE")

    search = request.args.get("q", "").strip()
    if search:
        clauses.append("(title ILIKE %s OR COALESCE(notes, '') ILIKE %s)")
        pattern = f"%{search}%"
        values.extend([pattern, pattern])

    where_clause = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    query = f"""
        SELECT {TASK_COLUMNS}
        FROM task_list_tasks
        {where_clause}
        ORDER BY completed ASC, due_date ASC NULLS LAST, created_at DESC
    """
    with connect() as connection:
        rows = connection.execute(query, values).fetchall()
    return jsonify([serialize_task(row) for row in rows])


@app.get(f"{API_PREFIX}/tasks/summary")
def get_task_summary():
    query = """
        SELECT
            COUNT(*)::integer AS total,
            COUNT(*) FILTER (WHERE completed = FALSE)::integer AS active,
            COUNT(*) FILTER (WHERE completed = TRUE)::integer AS completed,
            COUNT(*) FILTER (
                WHERE completed = FALSE AND due_date < NOW()
            )::integer AS overdue
        FROM task_list_tasks
    """
    with connect() as connection:
        summary = connection.execute(query).fetchone()
    return jsonify(summary)


@app.post(f"{API_PREFIX}/tasks")
def create_task():
    payload = require_object_body({"title", "notes", "priority", "dueDate"})
    title = clean_title(payload.get("title"))
    notes = clean_notes(payload.get("notes"))
    priority = clean_priority(payload.get("priority", "medium"))
    due_date = parse_due_date(payload.get("dueDate"))

    query = f"""
        INSERT INTO task_list_tasks (title, notes, priority, due_date)
        VALUES (%s, %s, %s, %s)
        RETURNING {TASK_COLUMNS}
    """
    with connect() as connection:
        row = connection.execute(
            query, (title, notes, priority, due_date)
        ).fetchone()
    return jsonify(serialize_task(row)), 201


@app.patch(f"{API_PREFIX}/tasks/<int:task_id>")
def update_task(task_id: int):
    payload = require_object_body(
        {"title", "notes", "completed", "priority", "dueDate"}
    )
    if not payload:
        raise APIError("Укажите хотя бы одно поле для изменения.")

    updates: list[str] = []
    values: list[Any] = []
    if "title" in payload:
        updates.append("title = %s")
        values.append(clean_title(payload["title"]))
    if "notes" in payload:
        updates.append("notes = %s")
        values.append(clean_notes(payload["notes"]))
    if "completed" in payload:
        if not isinstance(payload["completed"], bool):
            raise APIError("Статус выполнения должен быть логическим значением.")
        updates.append("completed = %s")
        values.append(payload["completed"])
    if "priority" in payload:
        updates.append("priority = %s")
        values.append(clean_priority(payload["priority"]))
    if "dueDate" in payload:
        updates.append("due_date = %s")
        values.append(parse_due_date(payload["dueDate"]))

    updates.append("updated_at = NOW()")
    values.append(task_id)
    query = f"""
        UPDATE task_list_tasks
        SET {", ".join(updates)}
        WHERE id = %s
        RETURNING {TASK_COLUMNS}
    """
    with connect() as connection:
        row = connection.execute(query, values).fetchone()
    if row is None:
        raise APIError("Задача не найдена.", 404)
    return jsonify(serialize_task(row))


@app.delete(f"{API_PREFIX}/tasks/<int:task_id>")
def delete_task(task_id: int):
    with connect() as connection:
        row = connection.execute(
            "DELETE FROM task_list_tasks WHERE id = %s RETURNING id",
            (task_id,),
        ).fetchone()
    if row is None:
        raise APIError("Задача не найдена.", 404)
    return jsonify({"deleted": True})


if __name__ == "__main__":
    raw_port = os.environ.get("PORT", "8000")
    try:
        port = int(raw_port)
    except ValueError as error:
        raise RuntimeError(f"Invalid PORT value: {raw_port}") from error
    app.run(host="0.0.0.0", port=port, debug=False)
